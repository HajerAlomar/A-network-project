package client;

//import com.sun.org.apache.xml.internal.serializer.utils.MsgKey;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Client extends javax.swing.JFrame {

    Socket socket;
    int port = 5000;
    InetAddress address;
    DataInputStream input;
    static DataOutputStream output;
    String username;
    String ServerAddress;

    public Client() {

        initComponents();
    }
    public static void sendPrivateChat(String dest) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String sentMessage = "private~" + dest + "~" + PublicVar.message;
                    output.writeUTF(sentMessage);
                    output.flush();

                } catch (IOException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        thread.start();

    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        ConnectToServerButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TypeMessageTextArea = new javax.swing.JTextArea();
        SendButton = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        PrivateListList = new javax.swing.JList<>();
        jLabel3 = new javax.swing.JLabel();
        StartPrivateButton = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 204, 204));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(51, 0, 51));
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel1.setFont(new java.awt.Font("Kristen ITC", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 102, 255));
        jLabel1.setText("Welcome in IMChat ");

        ConnectToServerButton.setBackground(new java.awt.Color(153, 255, 204));
        ConnectToServerButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        ConnectToServerButton.setText("join");
        ConnectToServerButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ConnectToServerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConnectToServerButtonActionPerformed(evt);
            }
        });

        TypeMessageTextArea.setColumns(20);
        TypeMessageTextArea.setFont(new java.awt.Font("Kristen ITC", 0, 14)); // NOI18N
        TypeMessageTextArea.setForeground(new java.awt.Color(153, 153, 153));
        TypeMessageTextArea.setRows(5);
        TypeMessageTextArea.setText("Type Your Message here");
        TypeMessageTextArea.setName("msg"); // NOI18N
        TypeMessageTextArea.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                TypeMessageTextAreaFocusGained(evt);
            }
        });
        jScrollPane2.setViewportView(TypeMessageTextArea);

        SendButton.setBackground(new java.awt.Color(102, 102, 255));
        SendButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        SendButton.setForeground(new java.awt.Color(255, 255, 255));
        SendButton.setText("Send");
        SendButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SendButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SendButtonActionPerformed(evt);
            }
        });

        PrivateListList.setBackground(new java.awt.Color(204, 204, 255));
        jScrollPane3.setViewportView(PrivateListList);

        jLabel3.setFont(new java.awt.Font("Kristen ITC", 0, 16)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 102, 255));
        jLabel3.setText("public chat:");

        StartPrivateButton.setBackground(new java.awt.Color(102, 102, 255));
        StartPrivateButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        StartPrivateButton.setForeground(new java.awt.Color(255, 255, 255));
        StartPrivateButton.setText("private chat ");
        StartPrivateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StartPrivateButtonActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Kristen ITC", 0, 10)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 51, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel4.setText("select one for private chat..");

        jLabel5.setFont(new java.awt.Font("Kristen ITC", 0, 16)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 102, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setText("online users:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                    .addComponent(StartPrivateButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(44, 44, 44)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(SendButton))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(253, 253, 253)
                                .addComponent(ConnectToServerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 7, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 582, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SendButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(ConnectToServerButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(StartPrivateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ConnectToServerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConnectToServerButtonActionPerformed
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
               
        if(!connected){
            ProcessClientConnection();
            ConnectToServerButton.setText("leave");
            ConnectToServerButton.setBackground(Color.red);

            connected=true;
        }else{
            ProcessClientDissconnection(); 
            ConnectToServerButton.setText("join");
            ConnectToServerButton.setBackground(new java.awt.Color(153, 255, 204));
            connected=false;
        }
            }
                
            
        });
        thread.start();	

    }//GEN-LAST:event_ConnectToServerButtonActionPerformed
    private void ProcessClientDissconnection(){
        DisconnectClient();
    }
    private void ProcessClientConnection(){
    boolean finish=false;
        while(true){
            username = JOptionPane.showInputDialog(this, "Enter your username","");
            ServerAddress=JOptionPane.showInputDialog(this,"Enter Server IP","192.168.1.26");
            if((username.length()<=10 &&username.length()>0)&&(ServerAddress.length()!=0 )){
                break;
            }else{
                if(username.equals("")){
                  JOptionPane.showMessageDialog(this, "Name can't be null");  
                }
                else{
                JOptionPane.showMessageDialog(this, "Enter a name that's less than or equal to 10 characters");
                }
            }
            
        }
        try {
            jLabel1.setText("Welcome in IMChat "  + username );
            address = InetAddress.getByName(ServerAddress);
            socket = new Socket(address, port);
            input = new DataInputStream(socket.getInputStream());
            output = new DataOutputStream(socket.getOutputStream());
        } catch (UnknownHostException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String dataReg = "reg~" + username;
                    output.writeUTF(dataReg);
                    output.flush();
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        });
        thread.start();
        ProcessClientChat();
}
    private void ProcessClientChat(){
        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (true) {
                        String receivedData = input.readUTF();
                        System.out.println(receivedData);
                        String[] receivedDataSpliter = receivedData.split("~");
                      if (receivedDataSpliter[0].equals("connected users")) {
                            PublishClientToList(receivedData);
                        } 
                      else  if (receivedDataSpliter[0].equals("pubmsg")) {
                            jTextArea1.append(receivedDataSpliter[1] + ":" + receivedDataSpliter[2] + "\n");
                        }
                      else if (receivedDataSpliter[0].equals("primsg")) {

                           if (PublicVar.privateChatStore.containsKey(receivedDataSpliter[1])) {
                             PublicVar.privateChatStore.get(receivedDataSpliter[1]).jTextArea1.append(receivedDataSpliter[1] + ":" +receivedDataSpliter[2]+ "\n");

                            } 
                            else if (!PublicVar.oldChatStore.containsKey(receivedDataSpliter[1])) {
                                 PrivateChat pc = new PrivateChat(receivedDataSpliter[1]);
                             
                                PublicVar.CH = receivedDataSpliter[1];
                                PublicVar.privateChatStore.put(receivedDataSpliter[1], pc);
                                pc.show();
                             PublicVar.privateChatStore.get(receivedDataSpliter[1]).jTextArea1.append(receivedDataSpliter[1] + ":" +receivedDataSpliter[2]+ "\n");
                            } else {

                                 PublicVar.privateChatStore.put(receivedDataSpliter[1], PublicVar.oldChatStore.get(receivedDataSpliter[1]));
                                 PublicVar.privateChatStore.get(receivedDataSpliter[1]).show();
                             PublicVar.privateChatStore.get(receivedDataSpliter[1]).jTextArea1.append(receivedDataSpliter[1] + ":" +receivedDataSpliter[2]+ "\n");

                        }
                      }

                    }
                } catch (IOException ex) {
                    System.out.println(username +" is disconnected");
                }
            }
        });
        thread2.start();
    }
    private void PublishClientToList(String data){
        data=data.replace("connected users~", "");
        String dataSplitter[]=data.split("~");
        DefaultListModel elements = new DefaultListModel();
        for (int i = 0; i < dataSplitter.length; i++) {
            if (!dataSplitter[i].equals(username)) {
                elements.addElement(dataSplitter[i]);
                
            }
        }
        PrivateListList.setModel(elements);
    }
    private void ClearListModel(){
        DefaultListModel listModel = (DefaultListModel) PrivateListList.getModel();
        listModel.removeAllElements();
        
    }
    private void DisconnectClient(){
        try {
            ClearListModel();
            output.writeUTF("end");
            output.flush();
            input.close();
            output.close();
            socket.close();
        } catch (IOException ex) {
            System.out.println();//here socket closed x
        }
    }
    private void SendButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SendButtonActionPerformed
             String message = TypeMessageTextArea.getText();
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String sentMessage = "public~" + message;
                    output.writeUTF(sentMessage);
                    output.flush();

                } catch (IOException ex) {
                    Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
                }
                 TypeMessageTextArea.setText("");
            }
        });
        thread.start();
    }//GEN-LAST:event_SendButtonActionPerformed

    private void StartPrivateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StartPrivateButtonActionPerformed

        if(!PublicVar.privateChatStore.containsKey(PrivateListList.getSelectedValue()) && !PublicVar.oldChatStore.containsKey(PrivateListList.getSelectedValue())){
        PrivateChat pc = new PrivateChat(PrivateListList.getSelectedValue());
        PublicVar.privateChatStore.put(PrivateListList.getSelectedValue(), pc);
           PublicVar.privateChatStore.get(PrivateListList.getSelectedValue()).show();
        }
        else if(PublicVar.oldChatStore.containsKey(PrivateListList.getSelectedValue())){
            PublicVar.privateChatStore.put(PrivateListList.getSelectedValue(), PublicVar.oldChatStore.get(PrivateListList.getSelectedValue()));
                PublicVar.oldChatStore.get(PrivateListList.getSelectedValue()).show();
                PublicVar.oldChatStore.remove(PrivateListList.getSelectedValue()).show();
         }
        else{
               PublicVar.privateChatStore.get(PrivateListList.getSelectedValue()).show();
        }
        
    }//GEN-LAST:event_StartPrivateButtonActionPerformed

    private void TypeMessageTextAreaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TypeMessageTextAreaFocusGained
        TypeMessageTextArea.setText("");
    }//GEN-LAST:event_TypeMessageTextAreaFocusGained

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        DisconnectClient();
    }//GEN-LAST:event_formWindowClosing

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Client.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Client().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private static javax.swing.JButton ConnectToServerButton;
    public static javax.swing.JList<String> PrivateListList;
    private javax.swing.JButton SendButton;
    private javax.swing.JButton StartPrivateButton;
    private javax.swing.JTextArea TypeMessageTextArea;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
    private boolean connected=false;
}
